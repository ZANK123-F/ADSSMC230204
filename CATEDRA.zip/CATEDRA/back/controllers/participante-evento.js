const { response } = require("express");
const { Evento, ParticipanteEvento, Usuario } = require("../models");

const obtenerParticipanteEvento = async (req, res = response) => {
    const { limite = 4 } = req.query;
    const { count, rows } = await ParticipanteEvento.findAndCountAll({
        // limit: limite,
        include: [
            { model: Usuario, as: "estudiante" },
            { model: Evento, as: "evento" },

        ]
    });
    res.json({
        count,
        "participantes": rows
    });
}

const crearNuevoParticipanteEvento = async (req, res = response) => {

    const { id_estudiante, id_evento } = req.body;

    try {
        const columns = {
            id_estudiante,
            id_evento
        }

        const participanteEvento = await ParticipanteEvento.create(columns);
        res.json({ participanteEvento });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            msg: 'Hable con el administrador'
        });
    }
}

const actualizarParticipanteEvento = async (req, res = response) => {
    const { id } = req.params;
    const { id_estudiante, id_evento } = req.body;

    const eventoDB = await ParticipanteEvento.findByPk(id);
    await eventoDB.update({
        id_estudiante, id_evento
    });
    await eventoDB.save();

    res.json({ participanteEvento: eventoDB });
}


const eliminarParticipanteEvento = async (req, res = response) => {
    const { id } = req.params;

    await ParticipanteEvento.destroy({
        where: {
            id,
        },
    });

    res.json({ success: 1 });
}

module.exports = {
    crearNuevoParticipanteEvento,
    obtenerParticipanteEvento,
    actualizarParticipanteEvento,
    eliminarParticipanteEvento,
}