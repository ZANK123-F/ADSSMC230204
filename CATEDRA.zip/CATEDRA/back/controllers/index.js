const AuthController = require('./auth');
const UsuarioController = require('./usuario');
const EstudianteController = require('./estudiante');
const AsistenciaController = require('./asistencia');
const EventoController = require('./evento');
const ParticipantEventoController = require('./participante-evento');
const NotaController = require('./nota');
const MateriaController = require('./materia');
const MateriaEstudianteController = require('./materia-estudiante');
const TareaController = require('./tarea');
const TareaEstudianteController = require('./tarea-estudiante');

module.exports = {
    AuthController,
    UsuarioController,
    EstudianteController,
    AsistenciaController,
    EventoController,
    ParticipantEventoController,
    NotaController,
    MateriaController,
    MateriaEstudianteController,
    TareaController,
    TareaEstudianteController,
}