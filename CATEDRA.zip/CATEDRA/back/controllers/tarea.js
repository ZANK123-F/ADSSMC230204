const { response } = require("express");
const { Tarea, Materia } = require("../models");
const { subirArchivo } = require('../helpers/subir-archivos');
const path = require("path");
const fs = require("fs");

const cloudinary = require('cloudinary').v2
cloudinary.config(process.env.CLOUDINARY_URL);

const obtenerTarea = async (req, res = response) => {
    const { limite = 4 } = req.query;
    const { count, rows } = await Tarea.findAndCountAll({
        include: [{ model: Materia, as: "materia" }]
    });

    res.json({
        count,
        tareas: rows,
    });
}

const crearTarea = async (req, res = response) => {
    const { nombre, fecha_entrega, id_materia } = req.body;
    const { tempFilePath } = req.files.archivo;
    const { secure_url } = await cloudinary.uploader.upload(tempFilePath);

    try {
        //const pathFile = await subirArchivo(req.files);

        const columns = {
            nombre, fecha_entrega, id_materia, documento_adjunto: secure_url
        }

        const tarea = await Tarea.create(columns);
        res.json({ tarea });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            msg: error
        });
    }
}

const actualizarTarea = async (req, res = response) => {
    const { id } = req.params;
    const { nombre, fecha_entrega, id_materia } = req.body;

    const tareaDB = await Tarea.findByPk(id);

    // Se elimina la tarea que tiene actualmente para crear el nuevo archivo
    if (tareaDB.documento_adjunto) {
        /*const pathImagen = path.join(__dirname, '../public', tareaDB.documento_adjunto);
        if (fs.existsSync(pathImagen)) {
            fs.unlinkSync(pathImagen);
        }*/
        const fileName = path.basename(tareaDB.documento_adjunto);
        const [publicId, extension] = fileName.split(".");
        await cloudinary.uploader.destroy(publicId, {
            invalidate: true
        });
    }

    //const nuevoDocumentoAdjunto = await subirArchivo(req.files);
    const { tempFilePath } = req.files.archivo;
    const { secure_url } = await cloudinary.uploader.upload(tempFilePath);

    await tareaDB.update({
        nombre, fecha_entrega, id_materia, documento_adjunto: secure_url
    });
    await tareaDB.save();

    res.json({ tarea: tareaDB });
}

const eliminarTarea = async (req, res = response) => {
    const { id } = req.params;

    const tareaDB = await Tarea.findByPk(id);

    if (tareaDB.documento_adjunto) {
        const fileName = path.basename(tareaDB.documento_adjunto);
        const [publicId, extension] = fileName.split(".");
        cloudinary.uploader.destroy(publicId, {
            invalidate: true
        });
    }

    await tareaDB.destroy();
    res.json({ success: 1 });
}

const mostrarArchivo = async (req, res = response) => {
    const { url } = req.query;
    const pathImagen = path.join(__dirname, '../uploads', url);
    if (!fs.existsSync(pathImagen)) {
        return res.sendFile(path.join(__dirname, '../public/no-found.png'));
    }

    return res.sendFile(pathImagen);
}

module.exports = {
    crearTarea,
    obtenerTarea,
    actualizarTarea,
    eliminarTarea,
    mostrarArchivo,
}