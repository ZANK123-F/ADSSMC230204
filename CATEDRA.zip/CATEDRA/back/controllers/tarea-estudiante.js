const { response } = require("express");
const { Tarea, TareaEstudiante, Usuario } = require("../models");

const obtenerTareaEstudiante = async (req, res = response) => {
    const { count, rows } = await TareaEstudiante.findAndCountAll({
        include: [
            { model: Tarea, as: "tarea" },
            { model: Usuario, as: "estudiante" },
        ]
    });
    res.json({
        count,
        tareasEstudiantes: rows
    });
}

const crearTareaEstudiante = async (req, res = response) => {

    const { id_tarea, id_estudiante } = req.body;

    try {
        const columns = {
            id_tarea, id_estudiante
        }

        const tarea = await TareaEstudiante.create(columns);
        res.json({ tarea });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            msg: 'Hable con el administrador'
        });
    }
}

const actualizarTareaEstudiante = async (req, res = response) => {
    const { id } = req.params;
    const { id_tarea, id_estudiante } = req.body;

    const tareaDB = await TareaEstudiante.findByPk(id);
    await tareaDB.update({
        id_tarea, id_estudiante
    });
    await tareaDB.save();

    res.json({ tareaEstudiante: tareaDB });
}


const eliminarTareaEstudiante = async (req, res = response) => {
    const { id } = req.params;

    await TareaEstudiante.destroy({
        where: {
            id,
        },
    });

    res.json({ success: 1 });
}

module.exports = {
    crearTareaEstudiante,
    obtenerTareaEstudiante,
    actualizarTareaEstudiante,
    eliminarTareaEstudiante,
}