const { response } = require("express");
const { Asistencia, Usuario } = require("../models");

const obtenerAsistencias = async (req, res = response) => {
    const { limite = 4 } = req.query;
    const { count, rows } = await Asistencia.findAndCountAll({
        // limit: limite,
        include: { model: Usuario, as: "estudiante" }
    });
    res.json({
        count,
        asistencias: rows
    });
}

const crearNuevoAsistencia = async (req, res = response) => {

    const { id_estudiante, dia, mes, anio, asistio } = req.body;

    try {
        const columns = {
            id_estudiante,
            dia,
            mes,
            anio,
            asistio
        }

        const existeAsistencia = await Asistencia.findOne({
            where: {
                id_estudiante,
                dia,
                mes,
                anio
            }
        });

        if (existeAsistencia) {
            return res.status(400).json({
                msg: 'Ya existe una asistencia identica',
            });
        }

        const asistencia = await Asistencia.create(columns);
        res.json({ asistencia });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            msg: 'Hable con el administrador'
        });
    }
}

const actualizarAsistencia = async (req, res = response) => {
    const { id } = req.params;
    const { id_estudiante, dia, mes, anio, asistio } = req.body;

    const asistenciaDB = await Asistencia.findByPk(id);
    await asistenciaDB.update({
        id_estudiante,
        dia,
        mes,
        anio,
        asistio
    });
    await asistenciaDB.save();

    res.json({ asistencia: asistenciaDB });
}


const eliminarAsistencia = async (req, res = response) => {
    const { id } = req.params;

    await Asistencia.destroy({
        where: {
            id,
        },
    });

    res.json({ success: 1 });
}

const porcentajeAsistencia = async (req, res = response) => {

    const { id_estudiante, mes, anio } = req.query;

    try {

        const { count, rows } = await Asistencia.findAndCountAll({
            where: { id_estudiante, mes, anio }
        })

        const totalAsistio = rows.filter(x => x.asistio).length || 0;
        const totalNoAsistio = rows.filter(x => !x.asistio).length || 0;

        let porcentajeAsistio = 0;
        let porcentajeNoAsistio = 0;

        if (count > 0) {
            porcentajeAsistio = (totalAsistio / count * 100).toFixed(2).concat("%");
            porcentajeNoAsistio = (totalNoAsistio / count * 100).toFixed(2).concat("%");
        }

        res.json({
            total: count,
            porcentajeAsistio,
            porcentajeNoAsistio,
            mes,
            anio,
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            msg: 'Hable con el administrador'
        });
    }
}

module.exports = {
    crearNuevoAsistencia,
    obtenerAsistencias,
    actualizarAsistencia,
    eliminarAsistencia,
    porcentajeAsistencia,
}