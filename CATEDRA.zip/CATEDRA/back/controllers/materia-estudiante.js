const { response } = require("express");
const { MateriaEstudiante, ParticipanteEvento, Usuario, Materia } = require("../models");

const obtenerMateriaEstudiante = async (req, res = response) => {
    const { limite = 4 } = req.query;
    const { count, rows } = await MateriaEstudiante.findAndCountAll({
        // limit: limite,
        include: [
            { model: Usuario, as: "estudiante" },
            { model: Usuario, as: "docente" },
            { model: Materia, as: "materia" },

        ]
    });
    res.json({
        count,
        "materiasXEstudiantes": rows
    });
}

const crearMateriaEstudiante = async (req, res = response) => {

    const { id_estudiante, id_materia, id_docente } = req.body;

    try {
        const columns = {
            id_estudiante, id_materia, id_docente
        }

        const participanteEvento = await MateriaEstudiante.create(columns);
        res.json({ participanteEvento });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            msg: 'Hable con el administrador'
        });
    }
}

const actualizarMateriaEstudiante = async (req, res = response) => {
    const { id } = req.params;
    const { id_estudiante, id_materia, id_docente } = req.body;

    const matDB = await MateriaEstudiante.findByPk(id);
    await matDB.update({
        id_estudiante, id_materia, id_docente
    });
    await matDB.save();

    res.json({ participanteEvento: matDB });
}


const eliminarMateriaEstudiante = async (req, res = response) => {
    const { id } = req.params;

    await MateriaEstudiante.destroy({
        where: {
            id,
        },
    });

    res.json({ success: 1 });
}

module.exports = {
    crearMateriaEstudiante,
    obtenerMateriaEstudiante,
    actualizarMateriaEstudiante,
    eliminarMateriaEstudiante,
}