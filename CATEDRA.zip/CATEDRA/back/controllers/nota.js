const { response } = require("express");
const { TipoEvaluacion, Usuario, Periodo, Nota, Materia } = require("../models");

const obtenerNota = async (req, res = response) => {
    const { limite = 4 } = req.query;
    const { count, rows } = await Nota.findAndCountAll({
        // limit: limite,
        include: [
            { model: Usuario, as: "estudiante" },
            { model: TipoEvaluacion, as: "tipoEvaluacion" },
            { model: Periodo, as: "periodo" },
            { model: Materia, as: "materia" },
        ]
    });
    res.json({
        count,
        "notas": rows
    });
}

const crearNuevaNota = async (req, res = response) => {

    const { id_estudiante, tipo_evaluacion_id, id_periodo, nota, id_materia } = req.body;
    try {
        const columns = {
            id_estudiante, tipo_evaluacion_id, id_periodo, nota, id_materia
        }

        const notaDB = await Nota.create(columns);
        res.json({ nota: notaDB });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            msg: 'Hable con el administrador'
        });
    }
}

const actualizarNota = async (req, res = response) => {
    const { id } = req.params;
    const { id_estudiante, tipo_evaluacion_id, id_periodo, nota, id_materia } = req.body;

    const notaDB = await Nota.findByPk(id);
    await notaDB.update({
        id_estudiante, tipo_evaluacion_id, id_periodo, nota, id_materia
    });
    await notaDB.save();

    res.json({ nota: notaDB });
}


const eliminarNota = async (req, res = response) => {
    const { id } = req.params;

    await Nota.destroy({
        where: {
            id,
        },
    });

    res.json({ success: 1 });
}

module.exports = {
    crearNuevaNota,
    obtenerNota,
    actualizarNota,
    eliminarNota,
}