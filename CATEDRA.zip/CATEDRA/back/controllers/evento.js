const { response } = require("express");
const { Evento } = require("../models");

const obtenerEventos = async (req, res = response) => {
    const { limite = 4 } = req.query;
    const { count, rows } = await Evento.findAndCountAll({
        
    });
    res.json({
        count,
        eventos: rows
    });
}

const crearNuevoEvento = async (req, res = response) => {

    const { nombre_evento, descripcion, fecha, ubicacion } = req.body;

    try {
        const columns = {
            nombre_evento,
            descripcion,
            fecha,
            ubicacion,
        }

        const evento = await Evento.create(columns);
        res.json({ evento });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            msg: 'Hable con el administrador'
        });
    }
}

const actualizarEvento = async (req, res = response) => {
    const { id } = req.params;
    const { nombre_evento, descripcion, fecha, ubicacion } = req.body;

    const eventoDB = await Evento.findByPk(id);
    await eventoDB.update({
        nombre_evento, descripcion, fecha, ubicacion
    });
    await eventoDB.save();

    res.json({ evento: eventoDB });
}


const eliminarEvento = async (req, res = response) => {
    const { id } = req.params;

    await Evento.destroy({
        where: {
            id,
        },
    });

    res.json({ success: 1 });
}

module.exports = {
    crearNuevoEvento,
    obtenerEventos,
    actualizarEvento,
    eliminarEvento,
}