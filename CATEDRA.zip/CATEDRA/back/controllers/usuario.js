const { response } = require("express");
const { Rol, Usuario } = require("../models");
const bcrypt = require("bcrypt");
const saltRounds = 10;
const { generarJWT } = require("../helpers/generar-jwt");

const obtenerUsuarios = async (req, res = response) => {


    // const { q, nombre, page, limit } = req.query;
    const { roleName } = req.query;

    let idRol = null;
    if (roleName) {
        const rol = await Rol.findOne({ where: { nombre: roleName } });
        idRol = rol.id;
    }
    const { count, rows } = await Usuario.findAndCountAll({
        //where: {}, // ponerle estado al usuario
        include: { model: Rol, as: "rol" },
        where: !idRol ? {} : { rol_id: idRol }
    });
    res.json({
        count,
        usuarios: rows,
    });
}


const crearNuevoUsuario = async (req, res = response) => {

    const { email, password, nombre, apellido, roleName } = req.body;

    try {
        // Generar JWT
        //const token = await generarJWT(usuario.js.id_usuario);
        const rol = await Rol.findOne({ where: { nombre: roleName } });
        const hash = bcrypt.hashSync(password, saltRounds);

        let carnet = null;
        if (rol.nombre !== "ADMIN_ROLE") {
            carnet = generarCarnet(nombre, apellido);
        }

        const columns = {
            email,
            password: hash,
            nombre,
            apellido,
            inicio_google: false,
            rol_id: rol.id,
            carnet,
        }

        const usuario = await Usuario.create(columns);

        // Generar JWT
        const token = await generarJWT(usuario.id);

        res.json({
            usuario,
            token
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            msg: 'Hable con el administrador'
        });
    }
}

const actualizarUsuario = async (req, res = response) => {
    const { id } = req.params;
    const { nombre,
        apellido,
        password,
        roleName,
        sexo,
        grado,
        centro_escolar,
        fecha_inscricion
    } = req.body;

    const usuarioDB = await Usuario.findByPk(id);
    // const rol = await Rol.findOne({ where: { nombre: roleName } });

    // Se valida si la contraseña fue cambiada así se actualiza la columna o no
    const match = bcrypt.compareSync(password, usuarioDB.password);
    let newPassword = usuarioDB.password;
    if (!match) {
        newPassword = bcrypt.hashSync(password, saltRounds);
    }

    await usuarioDB.update({
        nombre,
        apellido,
        password: newPassword,
        // rol_id: rol.id,
        sexo,
        grado,
        centro_escolar,
        fecha_inscricion,
    });
    await usuarioDB.save();

    res.json(usuarioDB);
}

const eliminarUsuario = async (req, res = response) => {
    const { id } = req.params;

    await Usuario.destroy({
        where: {
            id,
        },
    });

    res.json({ success: 1 });
}

const generarCarnet = (nombre, apellido) => {
    const letraUno = nombre.charAt(0).toUpperCase();
    const letraDos = apellido.charAt(0).toUpperCase();
    const anio = (new Date()).getFullYear();
    const randomNumber = Math.floor(Math.random() * 100);

    return `${letraUno}${letraDos}${anio}00${randomNumber}`;
}

module.exports = {
    crearNuevoUsuario,
    obtenerUsuarios,
    actualizarUsuario,
    eliminarUsuario,
    generarCarnet,
}