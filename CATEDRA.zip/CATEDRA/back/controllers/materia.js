const { response } = require("express");
const { Materia, MateriaEstudiante, Usuario, Rol } = require("../models");
const { sequelize } = require("../DB/config");

const obtenerMaterias = async (req, res = response) => {
    const { count, rows } = await Materia.findAndCountAll({

    });
    res.json({
        count,
        eventos: rows
    });
}

const crearMaterias = async (req, res = response) => {

    const { nombre } = req.body;

    try {
        const columns = {
            nombre,
            codigo_materia: generarCodigo(nombre),
        }

        const materia = await Materia.create(columns);
        res.json({ materia });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            msg: 'Hable con el administrador'
        });
    }
}

const actualizarMateria = async (req, res = response) => {
    const { id } = req.params;
    const { nombre } = req.body;

    const materiaDB = await Materia.findByPk(id);
    await materiaDB.update({
        nombre
    });
    await materiaDB.save();

    res.json({ materia: materiaDB });
}


const eliminarMateria = async (req, res = response) => {
    const { id } = req.params;

    await Materia.destroy({
        where: {
            id,
        },
    });

    res.json({ success: 1 });
}

const generarCodigo = (nombre) => {
    const letraUno = nombre.charAt(0).toUpperCase();
    const letraDos = nombre.charAt(1).toUpperCase();
    const letraTres = nombre.charAt(2).toUpperCase();
    const randomNumber = Math.floor(Math.random() * 1000);

    return `${letraUno}${letraDos}${letraTres}${randomNumber}`;
}

const materiasXDocente = async (req, res = response) => {
    const { id_docente } = req.query;
    const query = `
        SELECT DISTINCT
            u.id AS docente_id,
            CONCAT(u.nombre, ' ', u.apellido) AS docente,
            m.codigo_materia,
            m.nombre AS materia
        FROM materia_estudiante me
        INNER JOIN usuario u ON u.id = me.id_docente
        INNER JOIN rol r ON r.id = u.rol_id
        INNER JOIN materia m ON me.id_materia = m.id
        WHERE u.id = :docenteId`;

    const rows = await sequelize.query(query, {
        replacements: { docenteId: id_docente }, // Pasamos el parámetro de reemplazo de forma segura
        type: sequelize.QueryTypes.SELECT // Indicamos que esperamos un SELECT
    });

    res.json({
        materiasProfesor: rows
    });
}

const materiasXEstudiante = async (req, res = response) => {
    const { id_estudiante } = req.query;
    const query = `
        SELECT DISTINCT
            u.id AS docente_id,
            CONCAT(u.nombre, ' ', u.apellido) AS docente,
            m.codigo_materia,
            m.nombre AS materia
        FROM materia_estudiante me
        INNER JOIN usuario u ON u.id = me.id_estudiante
        INNER JOIN rol r ON r.id = u.rol_id
        INNER JOIN materia m ON me.id_materia = m.id
        WHERE u.id = :estudianteId`;

    const rows = await sequelize.query(query, {
        replacements: { estudianteId: id_estudiante }, // Pasamos el parámetro de reemplazo de forma segura
        type: sequelize.QueryTypes.SELECT // Indicamos que esperamos un SELECT
    });

    res.json({
        materiasEstudiante: rows
    });
}


module.exports = {
    crearMaterias,
    obtenerMaterias,
    actualizarMateria,
    eliminarMateria,
    materiasXDocente,
    materiasXEstudiante,
}