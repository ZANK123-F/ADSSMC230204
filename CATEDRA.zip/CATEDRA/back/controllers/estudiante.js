const {response} = require("express");
const {Estudiante} = require("../models");

const obtenerEstudiantes = async (req, res = response) => {
    const {limite = 4} = req.query;
    const {count, rows} = await Estudiante.findAndCountAll({
        //where: {}, // ponerle estado al usuario
        // limit: limite,
    });
    res.json({
        count,
        estudiantes: rows
    });
}


const crearNuevoEstudiante = async (req, res = response) => {

    const {nombre, apellido, sexo, grado, centro_escolar, fecha_inscripcion} = req.body;

    try {
        const columns = {
            nombre,
            apellido,
            sexo,
            grado,
            centro_escolar,
            fecha_inscripcion,
            carnet: generarCarnet(nombre, apellido),
        }

        const estudiante = await Estudiante.create(columns);
        res.json({estudiante,});
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            msg: 'Hable con el administrador'
        });
    }
}

const actualizarEstudiante = async (req, res = response) => {
    const {id} = req.params;
    const {nombre, apellido, sexo, grado, centro_escolar, fecha_inscripcion} = req.body;

    const usuarioDB = await Estudiante.findByPk(id);
    await usuarioDB.update({
        nombre,
        apellido,
        sexo,
        grado,
        centro_escolar,
        fecha_inscripcion,
    });
    await usuarioDB.save();

    res.json(usuarioDB);
}

const eliminarEstudiante = async (req, res = response) => {
    const {id} = req.params;

    await Estudiante.destroy({
        where: {
            id,
        },
    });

    res.json({success: 1});
}


const generarCarnet = (nombre, apellido) => {
    const letraUno = nombre.charAt(0).toUpperCase();
    const letraDos = apellido.charAt(0).toUpperCase();
    const anio = (new Date()).getFullYear();
    const randomNumber = Math.floor(Math.random() * 100);

    return `${letraUno}${letraDos}${anio}00${randomNumber}`;
}

module.exports = {
    crearNuevoEstudiante,
    obtenerEstudiantes,
    actualizarEstudiante,
    eliminarEstudiante,
}