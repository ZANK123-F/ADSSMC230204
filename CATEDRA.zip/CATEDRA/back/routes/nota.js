const { Router } = require('express');
const { check } = require('express-validator');

const {
    existeEstudiantePorId,
    existePeriodoPorId,
    existeNotaPorId,
    existeTipoEvaluacionPorId,
    existeMateriaPorId,
} = require('../helpers/db-validators');

const {
    validarCampos, validarJWT, esAdminRole
} = require('../middlewares');

const { NotaController } = require('../controllers');

const router = Router();

router.get('/', validarJWT, NotaController.obtenerNota);

router.post('/crear', [
    validarJWT,
    check("id_estudiante").custom(existeEstudiantePorId),
    check("tipo_evaluacion_id").custom(existeTipoEvaluacionPorId),
    check("id_periodo").custom(existePeriodoPorId),
    check("nota", "Nota requerida").notEmpty(),
    check("id_materia").custom(existeMateriaPorId),
    validarCampos
], NotaController.crearNuevaNota);

router.put('/actualizar/:id', [
    validarJWT,
    check("id").custom(existeNotaPorId),
    check("id_estudiante").custom(existeEstudiantePorId),
    check("tipo_evaluacion_id").custom(existeTipoEvaluacionPorId),
    check("id_periodo").custom(existePeriodoPorId),
    check("nota", "Nota requerida").notEmpty(),
    check("id_materia").custom(existeMateriaPorId),
    validarCampos,
], NotaController.actualizarNota);

router.delete('/eliminar/:id', [
    validarJWT,
    esAdminRole,
    check("id").custom(existeNotaPorId),
    validarCampos
], NotaController.eliminarNota);

module.exports = router;