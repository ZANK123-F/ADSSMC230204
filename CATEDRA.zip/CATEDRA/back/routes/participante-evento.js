const { Router } = require('express');
const { check } = require('express-validator');

const {
    existeEventoPorId,
    existeEstudiantePorId,
    existeParticipanteEventoPorId,
} = require('../helpers/db-validators');

const {
    validarCampos, validarJWT, esAdminRole
} = require('../middlewares');

const { ParticipantEventoController } = require('../controllers');

const router = Router();

router.get('/', validarJWT, ParticipantEventoController.obtenerParticipanteEvento);

router.post('/crear', [
    validarJWT,
    check("id_estudiante").custom(existeEstudiantePorId),
    check("id_evento").custom(existeEventoPorId),
    validarCampos
], ParticipantEventoController.crearNuevoParticipanteEvento);

router.put('/actualizar/:id', [
    validarJWT,
    check("id").custom(existeParticipanteEventoPorId),
    check("id_estudiante").custom(existeEstudiantePorId),
    check("id_evento").custom(existeEventoPorId),
    validarCampos,
], ParticipantEventoController.actualizarParticipanteEvento);

router.delete('/eliminar/:id', [
    validarJWT,
    esAdminRole,
    check('id').custom(existeParticipanteEventoPorId),
    validarCampos
], ParticipantEventoController.eliminarParticipanteEvento);

module.exports = router;