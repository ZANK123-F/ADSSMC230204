const {Router, response} = require('express');
const {check} = require('express-validator');
const upload = require("../helpers/subir-archivos")
const {
    existeTareaPorId, existeMateriaPorId
} = require('../helpers/db-validators');

const {
    validarCampos, validarJWT, esAdminRole
} = require('../middlewares');

const {TareaController} = require('../controllers');
const {validarExisteArchivo} = require("../middlewares/validar-archivos");

const router = Router();

router.get('/', validarJWT, TareaController.obtenerTarea);

router.post('/crear',
    validarJWT,
    validarExisteArchivo,
    check('nombre', 'El nombre es obligatorio').not().isEmpty(),
    check('fecha_entrega', 'la fecha es obligatorio').notEmpty(),
    check('id_materia').custom(existeMateriaPorId),
    validarCampos
    , TareaController.crearTarea);

router.put('/actualizar/:id', [
    validarJWT,
    validarExisteArchivo,
    check('id').custom(existeTareaPorId),
    check('nombre', 'El nombre es obligatorio').not().isEmpty(),
    check('fecha_entrega', 'la fecha es obligatorio').notEmpty(),
    check('id_materia').custom(existeMateriaPorId),
    validarCampos
], TareaController.actualizarTarea);

router.delete('/eliminar/:id', [
    validarJWT,
    esAdminRole,
    check('id').custom(existeTareaPorId),
    validarCampos
], TareaController.eliminarTarea);

router.get('/ver-archivo',
    check('url', 'Url del archivo es obligatorio').not().isEmpty(),
    validarCampos
    , TareaController.mostrarArchivo);

module.exports = router;