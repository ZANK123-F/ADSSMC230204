const { Router } = require('express');
const { check } = require('express-validator');

const {
    existeMateriaPorId,
    existeDocentePorId,
    existeEstudiantePorId
} = require('../helpers/db-validators');

const {
    validarCampos, validarJWT, esAdminRole
} = require('../middlewares');

const { MateriaController } = require('../controllers');

const router = Router();

router.get('/', validarJWT, MateriaController.obtenerMaterias);

router.post('/crear', [
    validarJWT,
    check('nombre', 'El nombre es obligatorio').not().isEmpty(),
    check('nombre', 'Minimo 3 caracteres').isLength({ min: 3 }),
    validarCampos
], MateriaController.crearMaterias);

router.put('/actualizar/:id', [
    validarJWT,
    check("id").custom(existeMateriaPorId),
    check('nombre', 'El nombre es obligatorio').not().isEmpty(),
    check('nombre', 'Minimo 3 caracteres').isLength({ min: 3 }),
    validarCampos,
], MateriaController.actualizarMateria);

router.delete('/eliminar/:id', [
    validarJWT,
    esAdminRole,
    check('id').custom(existeMateriaPorId),
    validarCampos
], MateriaController.eliminarMateria);

router.get('/materiasxdocente', [
    validarJWT,
    esAdminRole,
    check("id_docente", "docente es requerido").notEmpty(),
    check("id_docente").custom(existeDocentePorId),
    validarCampos
], MateriaController.materiasXDocente);

router.get('/materiasxestudiante', [
    validarJWT,
    esAdminRole,
    check("id_estudiante", "docente es requerido").notEmpty(),
    check("id_estudiante").custom(existeEstudiantePorId),
    validarCampos
], MateriaController.materiasXEstudiante);

module.exports = router;