const { Router } = require('express');
const { check } = require('express-validator');

const {
    existeTareaPorId, existeEstudiantePorId, existeTareaEstudiantePorId
} = require('../helpers/db-validators');

const {
    validarCampos, validarJWT, esAdminRole
} = require('../middlewares');

const { TareaEstudianteController } = require('../controllers');

const router = Router();

router.get('/', validarJWT, TareaEstudianteController.obtenerTareaEstudiante);

router.post('/crear', [
    validarJWT,
    check('id_tarea').custom(existeTareaPorId),
    check('id_estudiante').custom(existeEstudiantePorId),
    validarCampos
], TareaEstudianteController.crearTareaEstudiante);

router.put('/actualizar/:id', [
    validarJWT,
    check("id").custom(existeTareaEstudiantePorId),
    check('id_tarea').custom(existeTareaPorId),
    check('id_estudiante').custom(existeEstudiantePorId),
    validarCampos,
], TareaEstudianteController.actualizarTareaEstudiante);

router.delete('/eliminar/:id', [
    validarJWT,
    esAdminRole,
    check('id').custom(existeTareaEstudiantePorId),
    validarCampos
], TareaEstudianteController.eliminarTareaEstudiante);

module.exports = router;