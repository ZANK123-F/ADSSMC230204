const { Router } = require('express');
const { check } = require('express-validator');

const {
    existeEventoPorId
} = require('../helpers/db-validators');

const {
    validarCampos, validarJWT, esAdminRole
} = require('../middlewares');

const { EventoController } = require('../controllers');

const router = Router();

router.get('/', validarJWT, EventoController.obtenerEventos);

router.post('/crear', [
    validarJWT,
    check('nombre_evento', 'El nombre de evento es obligatorio').not().isEmpty(),
    check('fecha', 'Fecha es obligatorio').not().isEmpty(),
    validarCampos
], EventoController.crearNuevoEvento);

router.put('/actualizar/:id', [
    validarJWT,
    check("id").custom(existeEventoPorId),
    check('nombre_evento', 'El nombre de evento es obligatorio').not().isEmpty(),
    check('fecha', 'Fecha es obligatorio').not().isEmpty(),
    validarCampos,
], EventoController.actualizarEvento);

router.delete('/eliminar/:id', [
    validarJWT,
    esAdminRole,
    check('id').custom(existeEventoPorId),
    validarCampos
], EventoController.eliminarEvento);

module.exports = router;