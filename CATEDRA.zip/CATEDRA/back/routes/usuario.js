const {Router} = require('express');
const {check} = require('express-validator');

const {
    esRolValido, emailExiste,
    existeUsuarioPorId
} = require('../helpers/db-validators');

const {
    validarCampos, validarJWT, esAdminRole
} = require('../middlewares');


const {UsuarioController} = require('../controllers');

const router = Router();

router.get('/', validarJWT, UsuarioController.obtenerUsuarios);

router.post('/guardar', [
    check('email', 'El correo no es valido').isEmail(),
    check('password', 'El password es obligatorio y mayor a seis letras').isLength({min: 6}),
    check('nombre', 'El nombre es obligatorio').not().isEmpty(),
    check('roleName').custom(esRolValido),
    check('correo').custom(emailExiste),
    validarCampos
], UsuarioController.crearNuevoUsuario);

router.put('/actualizar/:id', [
    check('id').custom(existeUsuarioPorId),
    // check('roleName').custom(esRolValido),
    validarJWT,
    validarCampos,
], UsuarioController.actualizarUsuario);

router.delete('/eliminar/:id', [
    validarJWT,
    esAdminRole,
    check('id').custom(existeUsuarioPorId),
    validarCampos
], UsuarioController.eliminarUsuario);


module.exports = router;