const { Router } = require('express');
const { check } = require('express-validator');

const {
    existeAsistenciaPorId,
    existeEstudiantePorId
} = require('../helpers/db-validators');

const {
    validarCampos, validarJWT, esAdminRole
} = require('../middlewares');


const { AsistenciaController } = require('../controllers');

const router = Router();

router.get('/', validarJWT, AsistenciaController.obtenerAsistencias);

router.post('/crear', [
    validarJWT,
    check("id_estudiante").custom(existeEstudiantePorId),
    check('dia', 'El dia es obligatorio').not().isEmpty(),
    check('mes', 'El mes es obligatorio').not().isEmpty(),
    check('anio', 'El año es obligatorio').not().isEmpty(),
    check('asistio', 'Asistio solo puede ser 1 o 0').isIn(["0", "1"]),
    validarCampos
], AsistenciaController.crearNuevoAsistencia);

router.put('/actualizar/:id', [
    validarJWT,
    check("id_estudiante").custom(existeEstudiantePorId),
    check('dia', 'El dia es obligatorio').not().isEmpty(),
    check('mes', 'El mes es obligatorio').not().isEmpty(),
    check('anio', 'El año es obligatorio').not().isEmpty(),
    check('asistio', 'Asistio solo puede ser 1 o 0').isIn(["0", "1"]),
    validarCampos,
], AsistenciaController.actualizarAsistencia);

router.delete('/eliminar/:id', [
    validarJWT,
    esAdminRole,
    check('id').custom(existeAsistenciaPorId),
    validarCampos
], AsistenciaController.eliminarAsistencia);


router.get('/porcentaje-asistencia', [
    validarJWT,
    check("id_estudiante").custom(existeEstudiantePorId),
    check('mes', 'El mes es obligatorio').not().isEmpty(),
    check('anio', 'El año es obligatorio').not().isEmpty(),
    validarCampos
], AsistenciaController.porcentajeAsistencia);


module.exports = router;