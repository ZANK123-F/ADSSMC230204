const {Router} = require('express');
const {check} = require('express-validator');

const {
    esRolValido, emailExiste,
    existeEstudiantePorId
} = require('../helpers/db-validators');

const {
    validarCampos, validarJWT, esAdminRole
} = require('../middlewares');


const {EstudianteController} = require('../controllers');

const router = Router();

router.get('/', validarJWT, EstudianteController.obtenerEstudiantes);

router.post('/crear', [
    validarJWT,
    check('nombre', 'El nombre es obligatorio').not().isEmpty(),
    check('apellido', 'El apellido es obligatorio').not().isEmpty(),
    check('sexo', 'El sexo es obligatorio').not().isEmpty(),
    check('sexo', 'Sexo solo es M o F').isIn(["M", "F"]),
    check('grado', 'El grado es obligatorio').notEmpty(),
    check('centro_escolar', 'El centro_escolar es obligatorio').notEmpty(),
    check('fecha_inscripcion', 'El fecha_inscripcion es obligatorio').notEmpty(),
    validarCampos
], EstudianteController.crearNuevoEstudiante);

router.put('/actualizar/:id', [
    validarJWT,
    check('id').custom(existeEstudiantePorId),
    check('nombre', 'El nombre es obligatorio').not().isEmpty(),
    check('apellido', 'El apellido es obligatorio').not().isEmpty(),
    check('sexo', 'El sexo es obligatorio').not().isEmpty(),
    check('sexo', 'Sexo solo es M o F').isIn(["M", "F"]),
    check('grado', 'El grado es obligatorio').notEmpty(),
    check('centro_escolar', 'El centro_escolar es obligatorio').notEmpty(),
    check('fecha_inscripcion', 'El fecha_inscripcion es obligatorio').notEmpty(),
    validarCampos,
], EstudianteController.actualizarEstudiante);

router.delete('/eliminar/:id', [
    validarJWT,
    esAdminRole,
    check('id').custom(existeEstudiantePorId),
    validarCampos
], EstudianteController.eliminarEstudiante);


module.exports = router;