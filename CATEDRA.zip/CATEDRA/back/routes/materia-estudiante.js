const { Router } = require('express');
const { check } = require('express-validator');

const {
    existeEstudiantePorId,
    existeMateriaPorId,
    existeDocentePorId,
    existeMateriaXEstudiantePorId,
} = require('../helpers/db-validators');

const {
    validarCampos, validarJWT, esAdminRole
} = require('../middlewares');

const { MateriaEstudianteController } = require('../controllers');

const router = Router();

router.get('/', validarJWT, MateriaEstudianteController.obtenerMateriaEstudiante);

router.post('/crear', [
    validarJWT,
    check("id_estudiante").custom(existeEstudiantePorId),
    check("id_docente").custom(existeDocentePorId),
    check("id_materia").custom(existeMateriaPorId),
    validarCampos
], MateriaEstudianteController.crearMateriaEstudiante);

router.put('/actualizar/:id', [
    validarJWT,
    check("id").custom(existeMateriaXEstudiantePorId),
    check("id_estudiante").custom(existeEstudiantePorId),
    check("id_docente").custom(existeDocentePorId),
    check("id_materia").custom(existeMateriaPorId),
], MateriaEstudianteController.actualizarMateriaEstudiante);

router.delete('/eliminar/:id', [
    validarJWT,
    esAdminRole,
    check("id").custom(existeMateriaXEstudiantePorId),
    validarCampos
], MateriaEstudianteController.eliminarMateriaEstudiante);

module.exports = router;