const {Router} = require('express');
const {body, check} = require('express-validator');
const {AuthController, UsuarioController} = require('../controllers');

const {validarCampos} = require('../middlewares/validar-campos');
const {esRolValido} = require("../helpers/db-validators");

const router = Router();


router.post('/login', [
    body('email', 'El correo es obligatorio').isEmail(),
    body('password', 'La contraseña es obligatoria').notEmpty(),
    validarCampos
], AuthController.login);

router.post('/register',
    body("nombre", "Nombre requerido").notEmpty(),
    body("apellido", "Apellido requerido").notEmpty(),
    body("email", "correo invalido").isEmail(),
    body("password", "Contraseña requerida y Minimo 8 caracteres ").isLength({min: 8}),
    check('roleName').custom(esRolValido),
    validarCampos,
    UsuarioController.crearNuevoUsuario);


module.exports = router;