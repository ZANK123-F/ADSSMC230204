const { DataTypes } = require('sequelize');
const { sequelize } = require('../DB/config');

const Materia = sequelize.define('materia', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    codigo_materia: {
        type: DataTypes.STRING,
        allowNull: false
    },
    nombre: {
        type: DataTypes.STRING,
        allowNull: false
    },
},
    {
        freezeTableName: true,
        timestamps: false,
    }
);

module.exports = Materia;