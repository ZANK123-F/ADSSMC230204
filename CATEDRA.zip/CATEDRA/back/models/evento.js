const { DataTypes } = require('sequelize');
const { sequelize } = require('../DB/config');

const Evento = sequelize.define('evento', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    nombre_evento: {
        type: DataTypes.STRING,
        allowNull: false
    },
    descripcion: {
        type: DataTypes.STRING,
        allowNull: true
    },
    fecha: {
        type: DataTypes.DATE,
        allowNull: false
    },
    ubicacion: {
        type: DataTypes.STRING,
        allowNull: true
    },
},
    {
        freezeTableName: true,
        timestamps: false,
    }
);

module.exports = Evento;