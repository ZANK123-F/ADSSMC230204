const { DataTypes } = require('sequelize');
const { sequelize } = require('../DB/config');
const Rol = require('./rol');

const Usuario = sequelize.define('usuario', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    nombre: {
        type: DataTypes.STRING,
        allowNull: false
    },
    apellido: {
        type: DataTypes.STRING,
        allowNull: false
    },
    /*carnet: {
        type: DataTypes.STRING,
        allowNull: false
    },*/
    email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    rol_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    inicio_google: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
    },

    carnet: {
        type: DataTypes.STRING,
        allowNull: true
    },
    sexo: {
        type: DataTypes.ENUM,
        values: ['M', 'F'],
        allowNull: true
    },
    grado: {
        type: DataTypes.STRING,
        allowNull: true
    },
    centro_escolar: {
        type: DataTypes.STRING,
        allowNull: true
    },
    fecha_inscripcion: {
        type: DataTypes.STRING,
        allowNull: true
    },
},
    {
        freezeTableName: true,
        timestamps: false,
    }
);

Usuario.belongsTo(Rol, { foreignKey: 'rol_id', as: 'rol' });

module.exports = Usuario;