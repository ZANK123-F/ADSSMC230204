const Usuario = require('./usuario');
const Rol = require('./rol');
const Estudiante = require('./estudiante');
const Asistencia = require('./asistencia');
const Evento = require('./evento');
const ParticipanteEvento = require("./participante-evento");
const Nota = require("./nota");
const TipoEvaluacion = require("./tipoEvaluacion");
const Periodo = require("./periodo");
const Materia = require("./materia");
const MateriaEstudiante = require("./materia-estudiante");
const Tarea = require("./tarea");
const TareaEstudiante = require("./tarea-estudiante");

module.exports = {
    Usuario,
    Rol,
    Estudiante,
    Asistencia,
    Evento,
    ParticipanteEvento,
    Nota,
    TipoEvaluacion,
    Periodo,
    Materia,
    MateriaEstudiante,
    Tarea,
    TareaEstudiante,
}