const express = require('express');
const cors = require('cors');
const fileUpload = require('express-fileupload');
const https = require('https');
const fs = require('fs');

const options = {
    key: fs.readFileSync('private.key'),
    cert: fs.readFileSync('certificate.crt')
};

const { dbConnection, sequelize } = require('../DB/config');

class Server {

    constructor() {
        this.app = express();
        this.port = process.env.SERVER_PORT;

        // Direccion de las rutas de la app
        this.paths = {
            auth: '/api/auth',
            usuario: '/api/usuario',
            estudiante: '/api/estudiante',
            asistencia: '/api/asistencia',
            evento: '/api/evento',
            "participante-evento": "/api/participante-evento",
            nota: "/api/nota",
            materia: "/api/materia",
            "materia-estudiante": "/api/materia-estudiante",
            tarea: "/api/tarea",
            "tarea-estudiante": "/api/tarea-estudiante",
        };


        // Conectar a base de datos
        this.conectarDB().then();

        // Middlewares
        this.middlewares();

        //Rutas de mi app
        this.routes();
    }

    async conectarDB() {
        await dbConnection();
    }

    middlewares() {
        // CORS
        this.app.use(cors());

        // Lectura y parseo
        this.app.use(express.json());

        // Directorio public
        this.app.use(express.static('public'));

        // File Upload / Carga de archivos
        this.app.use(fileUpload({
            useTempFiles: true,
            tempFileDir: '/tmp/',
            createParentPath: true,
        }));
    }

    routes() {
        this.app.get("/ping", async (req, res) => {
            const [results, metadata] = await sequelize.query("select NOW()")
            res.json({
                results
            })
        })
        this.app.use(this.paths.auth, require('../routes/auth'));
        this.app.use(this.paths.usuario, require('../routes/usuario'));
        this.app.use(this.paths.estudiante, require('../routes/estudiante'));
        this.app.use(this.paths.asistencia, require('../routes/asistencia'));
        this.app.use(this.paths.evento, require('../routes/evento'));
        this.app.use(this.paths['participante-evento'], require('../routes/participante-evento'));
        this.app.use(this.paths.nota, require('../routes/nota'));
        this.app.use(this.paths.materia, require('../routes/materia'));
        this.app.use(this.paths['materia-estudiante'], require('../routes/materia-estudiante'));
        this.app.use(this.paths.tarea, require('../routes/tarea'));
        this.app.use(this.paths["tarea-estudiante"], require('../routes/tarea-estudiante'));

        this.app.get("/routes", async (req, res) => {
            res.json(this.getRoutes())
        })
    }

    listen() {
        if (process.env.SERVER_HTTPS !== "false") {
            // Crear el servidor HTTPS
            const server = https.createServer(options, this.app);
            server.listen(this.port, () => {
                console.log('Servidor HTTPS en ejecución en el puerto ' + this.port);
            });
        } else {
            this.app.listen(this.port, () => {
                console.log('Servidor corriendo en el puerto: ', this.port);
            });
        }
    }

    // Función para limpiar las rutas
    cleanPath = (regexp) => {
        // Convertimos las expresiones regulares a un string legible
        // Reemplaza las diagonales invertidas
        return regexp.toString()
            .replace('/^\\/', '/')         // Quita los símbolos de inicio y fin de regex
            .replace('\\/?(?=\\/|$)/i', '') // Limpia los patrones adicionales de Express
            .replace(/\\\//g, '/');
    };

    // Función para obtener las rutas disponibles
    getRoutes = () => {
        const routes = [];
        this.app._router.stack.forEach((middleware) => {
            if (middleware.route) { // Si es una ruta
                const methods = Object.keys(middleware.route.methods).join(', ').toUpperCase();
                const path = middleware.route.path;
                routes.push(`${methods} ${path}`);
            } else if (middleware.name === 'router') {
                // Para rutas en otros archivos
                middleware.handle.stack.forEach((nestedMiddleware) => {
                    if (nestedMiddleware.route) {
                        const methods = Object.keys(nestedMiddleware.route.methods).join(', ').toUpperCase();
                        const path = this.cleanPath(middleware.regexp) + nestedMiddleware.route.path;
                        routes.push(`${methods} ${path}`);
                    }
                });
            }
        });
        return routes;
    };


}


module.exports = Server;