const { DataTypes } = require('sequelize');
const { sequelize } = require('../DB/config');
const Usuario = require('./usuario');
const Evento = require('./evento');

const ParticipanteEvento = sequelize.define('participante_evento', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    id_estudiante: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    id_evento: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
},
    {
        freezeTableName: true,
        timestamps: false,
    }
);

ParticipanteEvento.belongsTo(Usuario, { foreignKey: 'id_estudiante', as: 'estudiante' });
ParticipanteEvento.belongsTo(Evento, { foreignKey: 'id_evento', as: 'evento' });

module.exports = ParticipanteEvento;