const { DataTypes } = require('sequelize');
const { sequelize } = require('../DB/config');
const Usuario = require('./usuario');

const Asistencia = sequelize.define('asistencia', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    id_estudiante: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    dia: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    mes: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    anio: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    asistio: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: 0,
    },

},
    {
        freezeTableName: true,
        timestamps: false,
    }
);

Asistencia.belongsTo(Usuario, { foreignKey: 'id_estudiante', as: 'estudiante' });

module.exports = Asistencia;