const { DataTypes } = require('sequelize');
const { sequelize } = require('../DB/config');
const Usuario = require('./usuario');
const TipoEvaluacion = require('./tipoEvaluacion');
const Periodo = require('./periodo');
const Materia = require('./materia');

const Nota = sequelize.define('nota', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    id_estudiante: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    id_periodo: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    nota: {
        type: DataTypes.FLOAT,
        allowNull: false,
    },
    tipo_evaluacion_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    id_materia: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
},
    {
        freezeTableName: true,
        timestamps: false,
    }
);

Nota.belongsTo(Usuario, { foreignKey: 'id_estudiante', as: 'estudiante' });
Nota.belongsTo(TipoEvaluacion, { foreignKey: 'tipo_evaluacion_id', as: 'tipoEvaluacion' });
Nota.belongsTo(Periodo, { foreignKey: 'id_periodo', as: 'periodo' });
Nota.belongsTo(Materia, { foreignKey: 'id_materia', as: 'materia' });

module.exports = Nota;