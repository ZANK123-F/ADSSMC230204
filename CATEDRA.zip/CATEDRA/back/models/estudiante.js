const {DataTypes} = require('sequelize');
const {sequelize} = require('../DB/config');

const Estudiante = sequelize.define('estudiante', {
        id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        },
        carnet: {
            type: DataTypes.STRING,
            allowNull: false
        },
        nombre: {
            type: DataTypes.STRING,
            allowNull: false
        },
        apellido: {
            type: DataTypes.STRING,
            allowNull: false
        },
        sexo: {
            type: DataTypes.ENUM,
            values: ['M', 'F'],
            allowNull: false
        },
        grado: {
            type: DataTypes.STRING,
            allowNull: false
        },
        centro_escolar: {
            type: DataTypes.STRING,
            allowNull: false
        },
        fecha_inscripcion: {
            type: DataTypes.STRING,
            allowNull: false
        },
    },
    {
        freezeTableName: true,
        timestamps: false,
    }
);

module.exports = Estudiante;