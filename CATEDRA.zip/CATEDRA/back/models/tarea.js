const {DataTypes} = require('sequelize');
const {sequelize} = require('../DB/config');
const Materia = require('./materia');
const Tarea = sequelize.define('tarea', {
        id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        },
        nombre: {
            type: DataTypes.STRING,
            allowNull: false
        },
        fecha_entrega: {
            type: DataTypes.STRING,
            allowNull: true
        },
        id_materia: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        documento_adjunto: {
            type: DataTypes.STRING,
            allowNull: false,
        }
    },
    {
        freezeTableName: true,
        timestamps: false,
    }
);

Tarea.belongsTo(Materia, { foreignKey: 'id_materia', as: 'materia' });

module.exports = Tarea;