const {DataTypes} = require('sequelize');
const {sequelize} = require('../DB/config');

const Rol = sequelize.define('rol', {
        id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        },
        nombre: {
            type: DataTypes.STRING,
            allowNull: false
        },
    },
    {
        timestamps: false,
        freezeTableName: true, // Pa que la tabla sea igual que la definicion
    }
);

module.exports = Rol;