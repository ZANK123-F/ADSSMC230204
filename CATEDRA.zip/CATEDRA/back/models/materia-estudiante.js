const { DataTypes } = require('sequelize');
const { sequelize } = require('../DB/config');
const Usuario = require('./usuario');
const Materia = require('./materia');

const MateriaEstudiante = sequelize.define('materia_estudiante', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    id_materia: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    id_estudiante: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    id_docente: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
},
    {
        freezeTableName: true,
        timestamps: false,
    }
);

MateriaEstudiante.belongsTo(Materia, { foreignKey: 'id_materia', as: 'materia' });
MateriaEstudiante.belongsTo(Usuario, { foreignKey: 'id_estudiante', as: 'estudiante' });
MateriaEstudiante.belongsTo(Usuario, { foreignKey: 'id_docente', as: 'docente' });

module.exports = MateriaEstudiante;