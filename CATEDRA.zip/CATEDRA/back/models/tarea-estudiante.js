const { DataTypes } = require('sequelize');
const { sequelize } = require('../DB/config');
const Usuario = require('./usuario');
const Tarea = require('./tarea');

const TareaEstudiante = sequelize.define('tarea_estudiante', {
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
    },
    id_estudiante: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    id_tarea: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
},
    {
        freezeTableName: true,
        timestamps: false,
    }
);

TareaEstudiante.belongsTo(Usuario, { foreignKey: 'id_estudiante', as: 'estudiante' });
TareaEstudiante.belongsTo(Tarea, { foreignKey: 'id_tarea', as: 'tarea' });

module.exports = TareaEstudiante;