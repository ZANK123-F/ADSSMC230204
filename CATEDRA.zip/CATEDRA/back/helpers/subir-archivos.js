const path = require('path');
const {v4: uuidv4} = require('uuid');
const fs = require('fs');

const validExtensions = ['jpg', 'jpeg', 'png', 'gif', "pdf"];

const subirArchivo = (files) => {
    return new Promise((resolve, reject) => {
        const {archivo} = files;
        const nombreCortado = archivo.name.split('.');
        const extension = nombreCortado[nombreCortado.length - 1];

        // Validar extension del archivo
        if (!validExtensions.includes(extension)) {
            return reject(`La extension ${extension} no es permitida - ${validExtensions}`);
        }

        const nombreTemp = `${uuidv4()}.${extension}`;
        const uploadPath = path.join(__dirname, '../uploads/', nombreTemp);
        const pathRelativo = 'uploads/' + nombreTemp;

        archivo.mv(uploadPath).then(r => resolve(nombreTemp)).catch((err) => reject(err));
    });

};


module.exports = {
    subirArchivo,
}