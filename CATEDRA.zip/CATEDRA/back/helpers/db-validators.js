const { Rol, Usuario, Estudiante, Asistencia, Evento, ParticipanteEvento, Periodo, Nota, TipoEvaluacion, Materia, MateriaEstudiante,
    Tarea,
    TareaEstudiante
} = require('../models');


const esRolValido = async (roleName = '') => {
    const existeRol = await Rol.findOne({
        where: { nombre: roleName }
    });
    if (!existeRol) {
        throw new Error(`El rol ${roleName} no esta registrado en la BD`);
    }
}

const emailExiste = async (email = '') => {
    // Verificar si existe el correo
    const existeEmail = await Usuario.findOne({ email });

    if (existeEmail) {
        throw new Error(`El correo ${email} ya ha sido registrado anteriormente`);
    }

};

const existeUsuarioPorId = async (id) => {
    // Verificar si existe el correo
    const existeID = await Usuario.findByPk(id);
    if (!existeID) {
        throw new Error(`El ID: ${id}, no existe.`);
    }
};

const existeEstudiantePorId = async (id) => {
    // Verificar si existe el correo
    const rol = await Rol.findOne({ where: { nombre: "ESTUDIANTE_ROLE" } })
    const existeID = await Usuario.findOne({
        where: {
            id,
            rol_id: rol.id
        }
    });
    if (!existeID) {
        throw new Error(`El ID: ${id}, no existe.`);
    }
};

const existeDocentePorId = async (id) => {
    // Verificar si existe el correo
    const rol = await Rol.findOne({ where: { nombre: "PROFESOR_ROLE" } })
    const existeID = await Usuario.findOne({
        where: {
            id,
            rol_id: rol.id
        }
    });
    if (!existeID) {
        throw new Error(`El DOcente con ID: ${id}, no existe.`);
    }
};
const existeAsistenciaPorId = async (id) => {
    // Verificar si existe el correo
    const existeID = await Asistencia.findByPk(id);
    if (!existeID) {
        throw new Error(`El ID: ${id}, no existe.`);
    }
};

const existeEventoPorId = async (id) => {
    // Verificar si existe el correo
    const existeID = await Evento.findByPk(id);
    if (!existeID) {
        throw new Error(`El ID: ${id}, no existe.`);
    }
};

const existeParticipanteEventoPorId = async (id) => {
    // Verificar si existe el correo
    const existeID = await ParticipanteEvento.findByPk(id);
    if (!existeID) {
        throw new Error(`El ID: ${id}, no existe.`);
    }
};

const existePeriodoPorId = async (id) => {
    // Verificar si existe el correo
    const existeID = await Periodo.findByPk(id);
    if (!existeID) {
        throw new Error(`El ID: ${id}, no existe.`);
    }
};

const existeNotaPorId = async (id) => {
    // Verificar si existe el correo
    const existeID = await Nota.findByPk(id);
    if (!existeID) {
        throw new Error(`El ID: ${id}, no existe.`);
    }
};

const existeTipoEvaluacionPorId = async (id) => {
    // Verificar si existe el correo
    const existeID = await TipoEvaluacion.findByPk(id);
    if (!existeID) {
        throw new Error(`El ID: ${id}, no existe.`);
    }
};


const existeMateriaPorId = async (id) => {
    // Verificar si existe el correo
    const existeID = await Materia.findByPk(id);
    if (!existeID) {
        throw new Error(`La materia con ID: ${id}, no existe.`);
    }
};

const existeMateriaXEstudiantePorId = async (id) => {
    // Verificar si existe el correo
    const existeID = await MateriaEstudiante.findByPk(id);
    if (!existeID) {
        throw new Error(`El ID: ${id}, no existe.`);
    }
};

const existeTareaPorId = async (id) => {
    // Verificar si existe el correo
    const existeID = await Tarea.findByPk(id);
    if (!existeID) {
        throw new Error(`La tarea con ID: ${id}, no existe.`);
    }
};

const existeTareaEstudiantePorId = async (id) => {
    // Verificar si existe el correo
    const existeID = await TareaEstudiante.findByPk(id);
    if (!existeID) {
        throw new Error(`La tarea-estudiante con ID: ${id}, no existe.`);
    }
};

module.exports = {
    esRolValido,
    emailExiste,
    existeUsuarioPorId,
    existeEstudiantePorId,
    existeDocentePorId,
    existeAsistenciaPorId,
    existeEventoPorId,
    existeParticipanteEventoPorId,
    existePeriodoPorId,
    existeNotaPorId,
    existeTipoEvaluacionPorId,
    existeMateriaPorId,
    existeMateriaXEstudiantePorId,
    existeTareaPorId,
    existeTareaEstudiantePorId,
}