const {response} = require("express");
const {Rol} = require("../models");

const esAdminRole = async (req, res = response, next) => {

    // Verifica si el usuario es admin
    const usuario = req.usuario;
    if (!usuario) {
        return res.status(500).json({
            message: 'Se quiere verificar el rol sin validar el token'
        });
    }

    const rol = await Rol.findByPk(usuario.rol_id);
    if (rol.nombre !== "ADMIN_ROLE") {
        return res.status(403).json({
            message: 'No tienes permisos para ejecutar esta accion'
        });
    }

    next();
};

const tieneRol = (...roles) => {
    return (req, res = response, next) => {
        const usuario = req.usuario;
        if (!usuario) {
            return res.status(500).json({
                message: 'Se quiere verificar el rol sin validar el token'
            });
        }

        if (!roles.includes(usuario.rol)) {
            return res.status(403).json({
                msg: `El servicio requiere uno de estos roles: ${roles}`
            });
        }

        next();
    };
};

module.exports = {
    esAdminRole,
    tieneRol
}