DROP DATABASE IF EXISTS inef;

CREATE DATABASE inef;

USE inef;

CREATE TABLE rol (
  id int PRIMARY KEY AUTO_INCREMENT,
  nombre varchar(50) NOT NULL
);

INSERT INTO rol (nombre)
VALUES
  ('ADMIN_ROLE'),
  ('ESTUDIANTE_ROLE'),
  ('PROFESOR_ROLE');

CREATE TABLE periodo (
  id int PRIMARY KEY AUTO_INCREMENT,
  nombre varchar(50) NOT NULL
);

INSERT INTO periodo (nombre)
VALUES
  ('Periodo 1'),
  ('Periodo 2'),
  ('Periodo 3'),
  ('Periodo 4');

CREATE TABLE tipo_evaluacion (
  id int PRIMARY KEY AUTO_INCREMENT,
  nombre varchar(50) NOT NULL
);

INSERT INTO tipo_evaluacion (nombre)
VALUES
  ('Examen'),
  ('Tarea'),
  ('Proyecto');

 CREATE TABLE usuario (
  id int PRIMARY KEY AUTO_INCREMENT,
  nombre varchar(255) NOT NULL,
  apellido varchar(255) NOT NULL,
  email varchar(100) NOT NULL,
  password varchar(255) NOT NULL,
  rol_id int(11) NOT NULL,
  inicio_google TINYINT(1) DEFAULT 0,

  -- DEL ESTUDIANTE
  carnet varchar(25),
  sexo enum('M', 'F') NULL,
  grado varchar(10) NULL,
  centro_escolar varchar(255) NULL,
  fecha_inscripcion date NULL,
  
  FOREIGN KEY (rol_id) REFERENCES rol(id)
);


CREATE TABLE asistencia (
  id int PRIMARY KEY AUTO_INCREMENT,
  id_estudiante int(11) NOT NULL,
  dia int NOT NULL,
  mes int NOT NULL,
  anio int NOT NULL,
  asistio TINYINT(1) DEFAULT 0,
  FOREIGN KEY (id_estudiante) REFERENCES usuario(id)
);

CREATE TABLE evento (
  id int PRIMARY KEY AUTO_INCREMENT,
  nombre_evento varchar(255) NOT NULL,
  descripcion varchar(500) DEFAULT NULL,
  fecha DATE NOT NULL,
  ubicacion varchar(255) NULL
);

CREATE TABLE participante_evento (
  id int PRIMARY KEY AUTO_INCREMENT,
  id_evento int(11) NOT NULL,
  id_estudiante int(11) NOT NULL,
  FOREIGN KEY (id_estudiante) REFERENCES usuario(id),
  FOREIGN KEY (id_evento) REFERENCES evento(id)
);


CREATE TABLE materia (
  id int PRIMARY KEY AUTO_INCREMENT,
  codigo_materia varchar(20) NOT NULL,
  nombre varchar(100) not null
);

INSERT INTO materia (codigo_materia, nombre)
VALUES
  ('CC0012', 'Ciencias'),
  ('SO837', 'Sociales'),
  ('MAT938', 'Matematicas Y Estadisticas'),
  ('LNG754', 'Lenguajes Oral Y Escrito');

CREATE TABLE nota (
  id int PRIMARY KEY AUTO_INCREMENT,
  id_estudiante int(11) NOT NULL,
  id_periodo int NOT NULL,
  nota DECIMAL(4, 2) NOT NULL,
  tipo_evaluacion_id INT NOT NULL,
  id_materia int not null,
  FOREIGN KEY (id_estudiante) REFERENCES usuario(id),
  FOREIGN KEY (id_periodo) REFERENCES periodo(id),
  FOREIGN KEY (tipo_evaluacion_id) REFERENCES tipo_evaluacion(id),
  FOREIGN KEY (id_materia) REFERENCES materia(id)
);


CREATE TABLE materia_estudiante (
  id int PRIMARY KEY AUTO_INCREMENT,
  id_materia int not null,
  id_estudiante int NOT NULL,
  id_docente int not null,
  FOREIGN KEY (id_materia) REFERENCES materia(id),
  FOREIGN KEY (id_estudiante) REFERENCES usuario(id),
  FOREIGN KEY (id_docente) REFERENCES usuario(id)
);


CREATE TABLE tarea (
  id int PRIMARY KEY AUTO_INCREMENT,
  nombre varchar(100) not null,
  fecha_entrega date,
  id_materia int NOT NULL,
  documento_adjunto varchar(500) not null,
  FOREIGN KEY (id_materia) REFERENCES materia(id)
);

CREATE TABLE tarea_estudiante (
  id int PRIMARY KEY AUTO_INCREMENT,
  id_tarea INT NOT NULL,
  id_estudiante INT NOT NULL,
  FOREIGN KEY (id_tarea) REFERENCES tarea(id),
  FOREIGN KEY (id_estudiante) REFERENCES usuario(id),
);

