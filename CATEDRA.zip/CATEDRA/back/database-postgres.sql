-- DROP DATABASE IF EXISTS inef;

-- CREATE DATABASE inef;

-- \c inef; -- Para conectarse a la base de datos en PostgreSQL

DROP TABLE IF EXISTS usuario;
DROP TABLE IF EXISTS participante_evento;
DROP TABLE IF EXISTS asistencia;
DROP TABLE IF EXISTS evento;
DROP TABLE IF EXISTS nota;
DROP TABLE IF EXISTS periodo;
DROP TABLE IF EXISTS estudiante;
DROP TABLE IF EXISTS tipo_evaluacion;
DROP TABLE IF EXISTS rol;
DROP TABLE IF EXISTS materia;
DROP TABLE IF EXISTS materia_estudiante;
DROP TABLE IF EXISTS tarea;
DROP TABLE IF EXISTS tarea_estudiante;

CREATE TABLE rol (
  id SERIAL PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL
);

INSERT INTO rol (nombre)
VALUES
  ('ADMIN_ROLE'),
  ('ESTUDIANTE_ROLE'),
  ('PROFESOR_ROLE');

CREATE TABLE periodo (
  id SERIAL PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL
);

INSERT INTO periodo (nombre)
VALUES
  ('Periodo 1'),
  ('Periodo 2'),
  ('Periodo 3'),
  ('Periodo 4');

CREATE TABLE tipo_evaluacion (
  id SERIAL PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL
);

INSERT INTO tipo_evaluacion (nombre)
VALUES
  ('Examen'),
  ('Tarea'),
  ('Proyecto');

CREATE TYPE sexo_enum AS ENUM ('M', 'F'); -- Definición del tipo ENUM en PostgreSQL

CREATE TABLE usuario (
  id SERIAL PRIMARY KEY,
  nombre VARCHAR(255) NOT NULL,
  apellido VARCHAR(255) NOT NULL,
  email VARCHAR(100) NOT NULL,
  password VARCHAR(255) NOT NULL,
  rol_id INT NOT NULL,
  inicio_google BOOLEAN DEFAULT FALSE,
  
  -- Datos del estudiante
  carnet varchar(25),
  sexo sexo_enum NULL,
  grado VARCHAR(10) NULL,
  centro_escolar VARCHAR(255) NULL,
  fecha_inscripcion DATE NULL,
  
  FOREIGN KEY (rol_id) REFERENCES rol(id)
);

CREATE TABLE asistencia (
  id SERIAL PRIMARY KEY,
  id_estudiante INT NOT NULL,
  dia INT NOT NULL,
  mes INT NOT NULL,
  anio INT NOT NULL,
  asistio BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (id_estudiante) REFERENCES usuario(id)
);

CREATE TABLE evento (
  id SERIAL PRIMARY KEY,
  nombre_evento VARCHAR(255) NOT NULL,
  descripcion VARCHAR(500) DEFAULT NULL,
  fecha DATE NOT NULL,
  ubicacion VARCHAR(255) NULL
);


CREATE TABLE participante_evento (
  id SERIAL PRIMARY KEY,
  id_evento INT NOT NULL,
  id_estudiante INT NOT NULL,
  FOREIGN KEY (id_estudiante) REFERENCES usuario(id),
  FOREIGN KEY (id_evento) REFERENCES evento(id)
);

CREATE TABLE materia (
  id SERIAL PRIMARY KEY,
  codigo_materia VARCHAR(20) NOT NULL,
  nombre VARCHAR(100) NOT NULL
);

INSERT INTO materia (codigo_materia, nombre)
VALUES
  ('CC0012', 'Ciencias'),
  ('SO837', 'Sociales'),
  ('MAT938', 'Matematicas Y Estadisticas'),
  ('LNG754', 'Lenguajes Oral Y Escrito');


CREATE TABLE nota (
  id SERIAL PRIMARY KEY,
  id_estudiante INT NOT NULL,
  id_periodo INT NOT NULL,
  nota DECIMAL(4, 2) NOT NULL,
  tipo_evaluacion_id INT NOT NULL,
  id_materia int not null,
  FOREIGN KEY (id_estudiante) REFERENCES usuario(id),
  FOREIGN KEY (id_periodo) REFERENCES periodo(id),
  FOREIGN KEY (tipo_evaluacion_id) REFERENCES tipo_evaluacion(id),
  FOREIGN KEY (id_materia) REFERENCES materia(id),
);

CREATE TABLE materia_estudiante (
  id SERIAL PRIMARY KEY,
  id_materia INT NOT NULL,
  id_estudiante INT NOT NULL,
  id_docente INT NOT NULL,
  FOREIGN KEY (id_materia) REFERENCES materia(id),
  FOREIGN KEY (id_estudiante) REFERENCES usuario(id),
  FOREIGN KEY (id_docente) REFERENCES usuario(id)
);

CREATE TABLE tarea (
  id SERIAL PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  fecha_entrega DATE,
  id_materia INT NOT NULL,
  documento_adjunto VARCHAR(500) NOT NULL,
  FOREIGN KEY (id_materia) REFERENCES materia(id)
);

CREATE TABLE tarea_estudiante (
  id SERIAL PRIMARY KEY,
  id_tarea INT NOT NULL,
  id_estudiante INT NOT NULL,
  FOREIGN KEY (id_tarea) REFERENCES tarea(id),
  FOREIGN KEY (id_estudiante) REFERENCES usuario(id),
);
