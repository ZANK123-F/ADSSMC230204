const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(
    process.env.DB_DATABASE,
    process.env.DB_USERNAME,
    process.env.DB_PASS,
    {
        dialect: process.env.DB_DIALECT,
        host: process.env.DB_HOST,
        dialectOptions: {
            ssl: {
                require: true,
                rejectUnauthorized: false // Ajusta según tus necesidades de seguridad
            }
        }
    }
);

const dbConnection = async () => {
    try {
        await sequelize.authenticate();
        console.log('Base de datos online');
    } catch (error) {
        console.log(error);
        throw new Error('Error a la iniciar la base de datos');
    }
};


module.exports = {
    dbConnection,
    sequelize
};